class Country {
  String name;
  String imgName;
  List<String> border;
  List<String> border2;

  Country(
      {required this.name,
      required this.imgName,
      required this.border,
      required this.border2});
}
