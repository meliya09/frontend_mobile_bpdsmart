import 'dart:convert';

import 'package:bpdsmart_diy/common/style.dart';
import 'package:bpdsmart_diy/models/SearchModel.dart';

import 'package:bpdsmart_diy/shared/constants/common.dart';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';

import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:bpdsmart_diy/routes/app_pages.dart';

// class SearchService {
//   final httpClient = http.Client();
//   final apiUrl = '${baseUrl}search';

//   Future<List<SearchModel>> getSearch() async {
//     final response = await httpClient.get(Uri.parse(apiUrl));
//     if (response.statusCode == 200) {
//       final data = searchModelFromJson(response.body);
//       debugPrint(data.toString());
//       return data;
//     } else {
//       throw Exception('Failed to load konvens');
//     }
//   }

// }
final http.Client httpClient = http.Client();

class SearchService {
  Future<List<SearchModel>> searchMenu(String kontenMenu) async {
    try {
      final String apiUrl = '${baseUrl}search/$kontenMenu';
      final http.Response response = await httpClient.get(
        Uri.parse(apiUrl),
        // ignore: always_specify_types
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      );

      debugPrint(response.body);

      // final response = await request.send();

      // if (response.statusCode == 200) {}

      if (response.statusCode == 200 || response.statusCode == 201) {
        final Map<String, dynamic> map = json.decode(response.body);
        final List<dynamic> data = map['data'];
        print(data[0]['konten_menu']);

        // print(data[0]['konten_menu']);
        // ignore: always_specify_types
        // Iterable it = json.decode(response.body);
        // List<SearchModel> list =
        //     it.map((item) => SearchModel.fromJson(item)).toList();

        // if (response.body != null) {
        //   final List<SearchModel> list = searchModelFromJson(response.body);
        // }

        // Iterable it = json.decode(response.body);
        // List<SearchModel> list =
        //     it.map((item) => SearchModel.fromJson(item)).toList();

        // if (list.isEmpty) {
        //   AwesomeDialog(
        //     context: Get.context!,
        //     dialogType: DialogType.warning,
        //     animType: AnimType.bottomSlide,
        //     dialogBackgroundColor: primaryColor,
        //     titleTextStyle: GoogleFonts.poppins(
        //       color: secondaryColor,
        //       fontSize: 30,
        //       fontWeight: FontWeight.w500,
        //     ),
        //     descTextStyle: GoogleFonts.poppins(
        //       color: secondaryColor,
        //       fontSize: 20,
        //       fontWeight: FontWeight.w400,
        //     ),
        //     btnOkOnPress: () {},
        //     // btnCancelOnPress: () {
        //     //   Get.toNamed(Routes.ADD_DEBITUR);
        //     // },
        //     desc: 'Data tidak ditemukan',
        //     title: 'Warning',
        //     btnCancelIcon: Icons.add_circle,
        //     btnCancelText: 'Buat Debitur Baru',
        //     btnCancelColor: Colors.blue,
        //     btnOkText: 'Cari Lagi',
        //     btnOkIcon: Icons.search,
        //     btnOkColor: Colors.blue,
        //   ).show();
        // }

        // return list.first;
      }

      if (response.statusCode == 400) {
        AwesomeDialog(
          context: Get.context!,
          titleTextStyle: GoogleFonts.poppins(
            color: secondaryColor,
            fontSize: 30,
            fontWeight: FontWeight.w500,
          ),
          dialogBackgroundColor: primaryColor,
          descTextStyle: GoogleFonts.poppins(
            color: secondaryColor,
            fontSize: 20,
            fontWeight: FontWeight.w400,
          ),
          dialogType: DialogType.error,
          animType: AnimType.bottomSlide,
          title: 'Error',
          desc: 'Field input tidak boleh kosong',
          btnOkOnPress: () {},
        ).show();
      }

      throw Exception('Failed to load post');
    } catch (e) {
      debugPrint(e.toString());

      throw Exception('Failed to load post');
    }
  }
}
