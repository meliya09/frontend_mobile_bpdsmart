class ApiConstants {
  // static const baseUrl = 'https://reqres.in';
  static const baseUrl = 'https://175e-182-2-68-178.ap.ngrok.io/';
}
