const baseUrl = 'https://175e-182-2-68-178.ap.ngrok.io/';

class CommonConstants {
  static const String test = 'test';
  static const num testNum = 1;
  static const double largeText = 40.0;
  static const double normalText = 22.0;
  static const double smallText = 16.0;
}
