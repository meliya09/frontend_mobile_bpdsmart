import 'package:bpdsmart_diy/common/style.dart';
import 'package:bpdsmart_diy/routes/routes.dart';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';

import 'package:get/get.dart';

import '../controllers/simulasi_kredit_controller.dart';

class SimulasiKreditView extends GetView<SimulasiKreditController> {
  SimulasiKreditView({Key? key}) : super(key: key);

  final data = Get.arguments;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Simulasi Kredit'),
        actions: <Widget>[
          IconButton(
            icon: new Icon(Icons.home, color: Colors.white, size: 30),
            onPressed: () {
              Get.toNamed(Routes.HOME);
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.all(16),
          child: FormBuilder(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Simulasi Kredit',
                  style: TextStyle(
                    color: Color.fromARGB(255, 139, 171, 185),
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(
                  height: 20.0,
                ),
                Column(
                  children: [
                    const SizedBox(
                      height: 8.0,
                    ),
                    Row(
                      children: [
                        Expanded(
                            child: FormBuilderTextField(
                          name: 'jumlah_pinjaman',
                          decoration: const InputDecoration(
                            labelText: 'Jumlah Pinjaman',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(
                                Radius.circular(10.0),
                              ),
                            ),
                          ),
                          keyboardType: TextInputType.number,
                        )),
                      ],
                    ),
                    const SizedBox(
                      height: 10.0,
                    ),
                    Row(
                      children: [
                        Expanded(
                            child: FormBuilderTextField(
                          name: 'jangka_waktu',
                          decoration: const InputDecoration(
                            labelText: 'Jangka Waktu (Bulan)',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(
                                Radius.circular(10.0),
                              ),
                            ),
                          ),
                          keyboardType: TextInputType.number,
                        )),
                      ],
                    ),
                    const SizedBox(
                      height: 10.0,
                    ),
                    Row(
                      children: [
                        Expanded(
                            child: FormBuilderTextField(
                          name: 'bunga_efektif',
                          decoration: const InputDecoration(
                            labelText: 'Bunga (%) Efektif',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(
                                Radius.circular(10.0),
                              ),
                            ),
                          ),
                          keyboardType: TextInputType.number,
                        )),
                      ],
                    ),
                    const SizedBox(
                      height: 20.0,
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          shape: const StadiumBorder(),
                          padding: const EdgeInsets.symmetric(
                              vertical: 10, horizontal: 80),
                          textStyle: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                          )),
                      onPressed: () {},
                      child: const Text('Cek Simulasi'),
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
