import 'dart:math';
import 'package:bpdsmart_diy/models/InfoBerita/InfoBerita.dart';
import 'package:bpdsmart_diy/services/api.dart';
import 'package:bpdsmart_diy/models/response/users_response.dart';
import 'package:bpdsmart_diy/modules/home/home.dart';
import 'package:bpdsmart_diy/services/infoberita/infoberita_api.dart';
import 'package:bpdsmart_diy/shared/shared.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:bpdsmart_diy/models/SearchModel.dart';
import 'package:bpdsmart_diy/services/search_api/search_services.dart';
import 'package:flutter/material.dart';

import '../../services/popular_provider.dart';

class HomeController extends GetxController {
  final ApiRepository apiRepository;

  HomeController({required this.apiRepository});

  List infoBeritaList = <InfoBerita>[].obs;
  final RxBool isLoading = false.obs;
  Rx<MainTabs> currentTab = MainTabs.home.obs;
  Rxn<UsersResponse> users = Rxn<UsersResponse>();
  // ignore: always_specify_types
  Rxn user = Rxn<Datum>();

  RxList lstPopular = List<dynamic>.empty(growable: true).obs;
  RxBool isDataProcessing = false.obs;
  RxBool isDataError = false.obs;
  var data = Get.arguments;
  late MainTab mainTab;
  late DiscoverTab discoverTab;
  late ResourceTab resourceTab;
  late InboxTab inboxTab;
  late MeTab meTab;

  @override
  void onInit() async {
    super.onInit();

    mainTab = MainTab();
    // loadUsers();

    discoverTab = DiscoverTab();
    resourceTab = ResourceTab();
    inboxTab = InboxTab();
    meTab = MeTab();
    fetchInfoBerita();
    getPopular();
  }

  // Future<void> loadUsers() async {
  //   var _users = await apiRepository.getUsers();
  //   if (_users!.data!.length > 0) {
  //     users.value = _users;
  //     users.refresh();
  //     _saveUserInfo(_users);
  //   }
  // }
  Future<void> fetchInfoBerita() async {
    isLoading.value = true;
    final Future<List<InfoBerita>> api = InfoBeritaService().getInfoBerita();
    final List<InfoBerita> result = await api;
    infoBeritaList = result;
    isLoading.value = false;
    update();
  }

  void getPopular() {
    try {
      isDataProcessing(true);
      PopularProvider().getPopular().then((List resp) {
        lstPopular.clear();
        isDataProcessing(false);
        lstPopular.addAll(resp);
        isDataError(false);
      }, onError: (err) {
        isDataProcessing(false);
        isDataError(true);
      });
    } catch (exception) {
      isDataProcessing(false);
      isDataError(true);
    }
  }

  void signout() {
    SharedPreferences prefs = Get.find<SharedPreferences>();
    prefs.clear();

    // Get.back();
    NavigatorHelper.popLastScreens(popCount: 2);
  }

  void _saveUserInfo(UsersResponse users) {
    Random random = new Random();
    int index = random.nextInt(users.data!.length);
    user.value = users.data![index];
    SharedPreferences prefs = Get.find<SharedPreferences>();
    prefs.setString(StorageConstants.userInfo, users.data![index].toRawJson());

    // var userInfo = prefs.getString(StorageConstants.userInfo);
    // var userInfoObj = Datum.fromRawJson(xx!);
    // print(userInfoObj);
  }

  void switchTab(index) {
    MainTabs tab = _getCurrentTab(index);
    currentTab.value = tab;
  }

  int getCurrentIndex(MainTabs tab) {
    switch (tab) {
      case MainTabs.home:
        return 0;
      case MainTabs.discover:
        return 1;
      case MainTabs.resource:
        return 2;
      case MainTabs.inbox:
        return 3;
      case MainTabs.me:
        return 4;
      default:
        return 0;
    }
  }

  MainTabs _getCurrentTab(int index) {
    switch (index) {
      case 0:
        return MainTabs.home;
      case 1:
        return MainTabs.discover;
      case 2:
        return MainTabs.resource;
      case 3:
        return MainTabs.inbox;
      case 4:
        return MainTabs.me;
      default:
        return MainTabs.home;
    }
  }

  @override
  void onReady() {
    super.onReady();
    getPopular();
  }

  @override
  void onClose() {
    super.onClose();
    getPopular();
  }

  //search
  // List searchList = <SearchModel>[].obs;
  // final menuController = TextEditingController();
  // final isSearchLoading = false.obs;

  // void fetchSearch() async {
  //   isLoading.value = true;
  //   final api = SearchService().getSearch();
  //   final result = await api;
  //   final kontenmenu = menuController.text;
  //   searchList = result;
  //   isLoading.value = false;
  //   update();
  // }

  List searchList = <SearchModel>[].obs;

  final RxBool isSearchLoading = false.obs;

  final TextEditingController menuController = TextEditingController();

  void fetchSearch() async {
    isSearchLoading.value = true;

    final SearchService api = SearchService();
    final SearchService result = await api;
    final String menu = menuController.text;
    final String kontenmenu = menuController.text;
    isSearchLoading.value = false;

    update();
  }
}
