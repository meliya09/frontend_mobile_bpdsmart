import 'package:bpdsmart_diy/modules/Search/search/controllers/search_controller.dart';
import 'package:bpdsmart_diy/modules/product_konvensional/detail_product/controllers/detail_product_controller.dart';
import 'package:bpdsmart_diy/modules/internal/detail_product_internal/controllers/detail_product_internal_controller.dart';
import 'package:bpdsmart_diy/modules/internal/detail_product_berita/controllers/detail_product_berita_controller.dart';
import 'package:get/get.dart';
import 'home_controller.dart';

class HomeBinding implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut<HomeController>(
        () => HomeController(apiRepository: Get.find()));
    Get.lazyPut<SearchController>(
      () => SearchController(),
    );
    Get.lazyPut<DetailProductInternalController>(
      () => DetailProductInternalController(),
    );
    Get.lazyPut<DetailProductBeritaController>(
      () => DetailProductBeritaController(),
    );
  }
}
