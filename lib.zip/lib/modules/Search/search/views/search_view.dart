import 'package:bpdsmart_diy/routes/app_pages.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../../../../shared/widgets/color_button.dart';
import '../controllers/search_controller.dart';
import 'package:google_fonts/google_fonts.dart';

class SearchView extends GetView<SearchController> {
  @override
  // Widget build(BuildContext context) {
  //   return Scaffold(
  //     appBar: AppBar(
  //       title: const Text("Search"),
  //       centerTitle: true,
  //     ),
  //     body: Container(
  //       padding: const EdgeInsets.all(16.0),
  //       child: SingleChildScrollView(
  //         clipBehavior: Clip.hardEdge,
  //         child: Column(
  //           crossAxisAlignment: CrossAxisAlignment.stretch,
  //           mainAxisAlignment: MainAxisAlignment.center,
  //           children: <Widget>[
  //             // Image.asset(
  //             //   'assets/images/search_section/search_header.png',
  //             //   alignment: Alignment.topCenter,
  //             //   fit: BoxFit.cover,
  //             //   height: 300,
  //             // ),
  //             TextFormField(
  //               decoration: const InputDecoration(
  //                 hintText: 'Search',
  //                 suffixIcon: Icon(Icons.search),
  //                 focusedBorder: OutlineInputBorder(
  //                   borderSide: BorderSide(color: Colors.blue),
  //                 ),
  //                 enabledBorder: OutlineInputBorder(
  //                   borderSide: BorderSide(color: Colors.grey),
  //                 ),
  //               ),
  //               controller: controller.menuController,
  //               keyboardType: TextInputType.text,
  //             ),
  //             const SizedBox(
  //               height: 15,
  //             ),
  //             colorButton(context,
  //                 controller.isSearchLoading.isFalse ? 'SEARCH' : 'PROSES',
  //                 () async {
  //               controller.fetchSearch();
  //             }),
  //             const SizedBox(
  //               height: 30,
  //             ),
  //             Obx(() {
  //               if (controller.isSearchLoading.value) {
  //                 return const Center(
  //                   child: CircularProgressIndicator(),
  //                 );
  //               }

  //               // if (controller.searchList.isEmpty) {
  //               //   return const Center(
  //               //     child: Text('Tidak ada data'),
  //               //   );
  //               // }

  //               // If Bad state: No Element in listDebtor

  //               // If list has no element then return empty list

  //               if (controller.searchList.isNotEmpty &&
  //                   controller.searchList.length > 1) {
  //                 return Column(
  //                   children: <Widget>[
  //                     const Text(
  //                       'Data tidak ditemukan',
  //                       style: TextStyle(
  //                         fontSize: 20,
  //                       ),
  //                     ),
  //                     // Image.asset(
  //                     //   'assets/images/search_section/search_404_2.png',
  //                     //   alignment: Alignment.center,
  //                     //   fit: BoxFit.cover,
  //                     //   height: 300,
  //                     // ),
  //                     TextButton(
  //                         onPressed: () {}, child: const Text('Konten Menu')),
  //                   ],
  //                 );
  //               }

  //               return ListView(
  //                 scrollDirection: Axis.vertical,
  //                 shrinkWrap: true,
  //                 children: <Widget>[
  //                   Center(
  //                     child: Text(
  //                       'Hasil Pencarian : ${controller.searchList[0].kontenMenu}',
  //                       style: const TextStyle(
  //                           fontSize: 15, fontWeight: FontWeight.w200),
  //                     ),
  //                   ),
  //                   const SizedBox(
  //                     height: 20,
  //                   ),
  //                   ListTile(
  //                     title: Text(
  //                       controller.searchList[0].kontenMenu.toString(),
  //                       style: GoogleFonts.poppins(
  //                         fontSize: 20,
  //                         fontWeight: FontWeight.w500,
  //                       ),
  //                     ),

  //                     // onTap: () {
  //                     //   Get.toNamed(
  //                     //     Routes.SEARCH,
  //                     //     arguments: controller.searchList[0],
  //                     //   );
  //                     // },
  //                     // trailing: const Icon(Icons.keyboard_arrow_right),
  //                     // leading: CircleAvatar(
  //                     //   backgroundColor: Colors.blue,
  //                     //   maxRadius: 50,
  //                     //   child: Text(
  //                     //     controller.searchList[0].peminjam1
  //                     //         .toString()
  //                     //         .substring(0, 1),
  //                     //     style: const TextStyle(
  //                     //       fontSize: 30,
  //                     //       color: Colors.white,
  //                     //     ),
  //                     //   ),
  //                     // ),
  //                   ),
  //                 ],
  //               );
  //             })
  //           ],
  //         ),
  //       ),
  //     ),
  //   );
  // }

  // @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ListView Filter'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          // ignore: always_specify_types
          children: [
            const SizedBox(
              height: 20,
            ),
            TextFormField(
              decoration: const InputDecoration(
                hintText: 'Masukkan NIK',
                suffixIcon: Icon(Icons.search),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.blue),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey),
                ),
              ),
              controller: controller.menuController,
              keyboardType: TextInputType.number,
            ),
            const SizedBox(
              height: 20,
            ),
            Expanded(child: Obx(() {
              if (controller.isSearchLoading.value) {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              }

              if (controller.searchList.isEmpty) {
                return const Center(
                  child: Text('Tidak ada data'),
                );
              }

              // If Bad state: No Element in listDebtor

              // If list has no element then return empty list

              if (controller.searchList.isNotEmpty &&
                  controller.searchList.length > 1) {
                return Column(
                  children: <Widget>[
                    const Text(
                      'Data tidak ditemukan',
                      style: TextStyle(
                        fontSize: 20,
                      ),
                    ),
                    Image.asset(
                      'assets/images/search_section/search_404_2.png',
                      alignment: Alignment.center,
                      fit: BoxFit.cover,
                      height: 300,
                    ),
                    TextButton(
                        onPressed: () {}, child: const Text('Create Debitur')),
                  ],
                );
              }

              return ListView(
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                children: <Widget>[
                  Center(
                    child: Text(
                      'Found 1 result : ${controller.searchList[0].kontenMenu}',
                      style: const TextStyle(
                          fontSize: 15, fontWeight: FontWeight.w200),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  ListTile(
                    title: Text(
                      controller.searchList[0].kontenMenu.toString(),
                      style: GoogleFonts.poppins(
                        fontSize: 20,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    // subtitle: Text(
                    //   controller.listDebtor[0].bidangUsaha.toString(),
                    // ),
                    onTap: () {
                      // Get.toNamed(
                      //   Routes.DEBITUR_DETAIL,
                      //   arguments: controller.listDebtor[0],
                      // );
                    },
                    trailing: const Icon(Icons.keyboard_arrow_right),
                    leading: CircleAvatar(
                      backgroundColor: Colors.blue,
                      maxRadius: 50,
                      child: Text(
                        controller.searchList[0].kontenMenu
                            .toString()
                            .substring(0, 1),
                        style: const TextStyle(
                          fontSize: 30,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              );
            })
                // Obx(
                //   () => ListView.builder(
                //     itemCount: controller.searchList.length,
                //     itemBuilder: (BuildContext context, int index) {
                //       return ListTile(
                //         title: Text(
                //             controller.searchList[index].kontenMenu.toString()),
                //       );
                //     },
                //   ),
                // ),
                ),
          ],
        ),
      ),
    );
  }
}







// import 'package:bpdsmart_diy/routes/routes.dart';
// import 'package:bpdsmart_diy/services/search_api/search_services.dart';
// import 'package:flutter/material.dart';

// import 'package:get/get.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// import '../controllers/search_controller.dart';

// class SearchView extends GetView<SearchController> {
//   const SearchView({Key? key}) : super(key: key);
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         appBar: AppBar(
//           title: const Text(
//             'Search',
//             // style: TextStyle(color: oldLavender),
//           ),
//           centerTitle: true,
//         ),
//         body: Container(
//           padding: const EdgeInsets.all(16),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               GetBuilder<SearchController>(
//                 init: SearchController(),
//                 builder: (_) {
//                   return FutureBuilder(
//                     future: SearchService().getSearch(),
//                     builder: (context, AsyncSnapshot snapshot) {
//                       if (snapshot.hasData) {
//                         return ListView.builder(
//                           shrinkWrap: true,
//                           itemCount: snapshot.data!.length,
//                           itemBuilder: (context, index) {
                           
//                           },
//                         );
//                       } else {
//                         return const Center(
//                           child: CircularProgressIndicator(),
//                         );
//                       }
//                     },
//                   );
//                 },
//               ),
//             ],
//           ),
//         ));
//   }
// }

                        

//                           // return Card(
//                           //     semanticContainer: true,
//                           //     clipBehavior: Clip.antiAliasWithSaveLayer,
//                           //     shape: RoundedRectangleBorder(
//                           //       borderRadius: BorderRadius.circular(10.0),
//                           //     ),
//                           //     elevation: 5,
//                           //     color: const Color.fromARGB(255, 194, 190, 231),
//                           //     margin: const EdgeInsets.all(10),
//                           //     child: Column(
//                           //       children: [
//                           //         // const SizedBox(
//                           //         //   height: 20.0,
//                           //         // ),
//                           //         // SizedBox(
//                           //         //   width: 100,
//                           //         //   child: Text(
//                           //         //     snapshot.data![index].stafNama
//                           //         //         .toString(),
//                           //         //     // style: text,
//                           //         //     textAlign: TextAlign.left,
//                           //         //   ),
//                           //         // ),
//                           //         Row(
//                           //             // mainAxisAlignment:
//                           //             //     MainAxisAlignment.spaceBetween,
//                           //             children: <Widget>[
//                           //               const Align(
//                           //                 alignment: Alignment.center,
//                           //                 child: Text(
//                           //                   'Staff Nama',
//                           //                 ),
//                           //               ),
//                           //               const Align(
//                           //                 alignment: Alignment.center,
//                           //                 child: Text(
//                           //                   ':',
//                           //                 ),
//                           //               ),
//                           //               Align(
//                           //                 alignment: Alignment.center,
//                           //                 child: Text(
//                           //                   snapshot.data![index].stafNama
//                           //                       .toString(),
//                           //                 ),
//                           //               )
//                           //             ]),
//                           //         Row(
//                           //           mainAxisAlignment:
//                           //               MainAxisAlignment.spaceBetween,
//                           //           children: <Widget>[
//                           //             const Text(
//                           //               'Staff Jabatan',
//                           //             ),
//                           //             const Text(
//                           //               ':',
//                           //             ),
//                           //             Text(
//                           //               snapshot.data![index].stafJabatan
//                           //                   .toString(),
//                           //             ),
//                           //           ],
//                           //         ),
//                           //         Row(
//                           //           mainAxisAlignment:
//                           //               MainAxisAlignment.spaceBetween,
//                           //           children: <Widget>[
//                           //             const Text(
//                           //               'Staff Email',
//                           //             ),
//                           //             const Text(
//                           //               ':',
//                           //             ),
//                           //             Text(
//                           //               snapshot.data![index].stafEmail
//                           //                   .toString(),
//                           //             ),
//                           //           ],
//                           //         ),
//                           //         Row(
//                           //           mainAxisAlignment:
//                           //               MainAxisAlignment.spaceBetween,
//                           //           children: <Widget>[
//                           //             const Text(
//                           //               'Staff Telp',
//                           //             ),
//                           //             const Text(
//                           //               ':',
//                           //             ),
//                           //             Text(
//                           //               snapshot.data![index].stafTelp
//                           //                   .toString(),
//                           //             ),
//                           //           ],
//                           //         ),
//                           //         Row(
//                           //           mainAxisAlignment:
//                           //               MainAxisAlignment.spaceBetween,
//                           //           children: <Widget>[
//                           //             const Text(
//                           //               'Divisi',
//                           //             ),
//                           //             const Text(
//                           //               ':',
//                           //             ),
//                           //             Text(
//                           //               snapshot.data![index].levelNama
//                           //                   .toString(),
//                           //             ),
//                           //           ],
//                           //         ),
//                           //       ],
//                           //     ));
//                           // },
//                         // );
// //                       } else {
// //                         return const Center(
// //                           child: CircularProgressIndicator(),
// //                         );
// //                       }
// //                     },
// //                   );
// //                 },
// //               ),
// //             ],
// //           ),
// //         ));
// //   }
// // }
