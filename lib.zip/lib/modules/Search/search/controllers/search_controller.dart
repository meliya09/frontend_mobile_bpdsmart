import 'package:bpdsmart_diy/models/SearchModel.dart';
import 'package:bpdsmart_diy/services/search_api/search_services.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';

// class SearchController extends GetxController {
//   // List searchList = <SearchModel>[].obs;
//   // final isLoading = false.obs;
//   List searchList = <SearchModel>[].obs;

//   final isSearchLoading = false.obs;

//   final menuController = TextEditingController();

//   @override
//   void onInit() {
//     fetchSearch();
//     super.onInit();
//   }

//   void fetchSearch() async {
//     isSearchLoading.value = true;

//     // final api = SearchService().getSearch();
//     final api = SearchService();
//     final result = await api;
//     final menu = menuController.text;
//     final kontenmenu = menuController.text;
//     // searchList = result;
//     isSearchLoading.value = false;

//     update();
//   }

//   // void fetchSearch() async {
//   //   isLoading.value = true;
//   //   final api = SearchService().getSearch();
//   //   final result = await api;
//   //   final kontenmenu = menuController.text;
//   //   searchList = result;
//   //   isLoading.value = false;
//   //   update();
//   // }

//   // @override
//   // void onClose() {}
//   // void filterSearch(String KontenMenu) {
//   //   searchList = searchList
//   //       .where(
//   //           (element) => element.KontenMenu.toLowerCase().contains(KontenMenu))
//   //       .toList();
//   //   update();
//   // }
// }

class SearchController extends GetxController {
  final searchList = <SearchModel>[].obs;
  SearchService searchService = SearchService();

  final isSearchLoading = false.obs;
  final TextEditingController menuController = TextEditingController();

  void fetchSearch() async {
    isSearchLoading.value = true;

    final SearchService api = SearchService();
    final String menu = menuController.text;

    api.searchMenu(menu).then((List<SearchModel> searchService) {
      searchList.value = searchService;
      isSearchLoading.value = false;
      // ignore: always_specify_types
    }, onError: (error) {
      // print(error);
      isSearchLoading.value = false;
    });

    update();
  }
}
