class ApiConstants {
  // static const baseUrl = 'https://reqres.in';
  static const baseUrl = 'http://192.168.100.215:8080';
}
