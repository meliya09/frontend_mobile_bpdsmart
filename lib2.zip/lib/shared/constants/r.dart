class R {
  static final String assetsTODO = '';
}
