class StorageConstants {
  static final String token = 'token';
  static final String userInfo = 'userInfo';
}
