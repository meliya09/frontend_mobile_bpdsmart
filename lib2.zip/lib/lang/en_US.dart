const Map<String, String> en_US = {
  'covid': 'Corona Virus',
  'total_confirmed': 'Total Confirmed',
  'total_deaths': 'Total Deaths',
  'fetch_country': 'Fetch by country',
  'corona_by_country': 'Corona by country',
  'total_infecteds': 'Total Infecteds',
  'details': 'Details',
  'total_recovered': 'Total Recovered',
};
