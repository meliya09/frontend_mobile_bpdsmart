// To parse this JSON data, do
//
//     final produkKonvenModel = produkKonvenModelFromJson(jsonString);

import 'dart:convert';

List<HelpdeskModel> helpdeskModelFromJson(String str) =>
    List<HelpdeskModel>.from(
        json.decode(str).map((x) => HelpdeskModel.fromJson(x)));

String helpdeskModelToJson(List<HelpdeskModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class HelpdeskModel {
  HelpdeskModel({
    required this.stafId,
    required this.levelId,
    this.stafAkses,
    this.stafAdmin,
    this.stafNIP,
    required this.stafNama,
    this.stafGelar,
    required this.stafJabatan,
    this.stafTempatlahir,
    this.stafTgllahir,
    this.stafAlamat,
    this.stafKelamin,
    this.stafAgama,
    required this.stafTelp,
    required this.stafEmail,
    this.stafPassword,
    this.stafUpdatepassword,
    this.stafWa,
    this.stafFoto,
    this.stafStatus,
    this.levelKode,
    this.levelNama,
    this.levelAkses,
  });

  String stafId;
  String levelId;
  dynamic stafAkses;
  dynamic stafAdmin;
  dynamic stafNIP;
  String stafNama;
  dynamic stafGelar;
  String stafJabatan;
  dynamic stafTempatlahir;
  dynamic stafTgllahir;
  dynamic stafAlamat;
  dynamic stafKelamin;
  dynamic stafAgama;
  String stafTelp;
  String stafEmail;
  dynamic stafPassword;
  dynamic stafUpdatepassword;
  dynamic stafWa;
  dynamic stafFoto;
  dynamic stafStatus;
  dynamic levelKode;
  dynamic levelNama;
  dynamic levelAkses;

  factory HelpdeskModel.fromJson(Map<String, dynamic> json) => HelpdeskModel(
        stafId: json["staf_id"],
        levelId: json["level_id"],
        stafAkses: json["staf_akses"],
        stafAdmin: json["staf_admin"],
        stafNIP: json["staf_nip"],
        stafNama: json["staf_nama"],
        stafGelar: json["staf_gelar"],
        stafJabatan: json["staf_jabatan"],
        stafTempatlahir: json["staf_tempatlahir"],
        stafTgllahir: json["staf_tgllahir"],
        stafAlamat: json["staf_alamat"],
        stafKelamin: json["staf_kelamin"],
        stafAgama: json["staf_agama"],
        stafTelp: json["staf_telp"],
        stafEmail: json["staf_email"],
        stafPassword: json["staf_password"],
        stafUpdatepassword: json["staf_updatepassword"],
        stafWa: json["staf_wa"],
        stafFoto: json["staf_foto"],
        stafStatus: json["staf_status"],
        levelKode: json["level_kode"],
        levelNama: json["level_nama"],
        levelAkses: json["level_akses"],
      );

  Map<String, dynamic> toJson() => {
        "staf_id": stafId,
        "level_id": levelId,
        "staf_akses": stafAkses,
        "staf_admin": stafAdmin,
        "staf_nip": stafNIP,
        "staf_nama": stafNama,
        "staf_gelar": stafGelar,
        "staf_jabatan": stafJabatan,
        "staf_tempatlahir": stafTempatlahir,
        "staf_tgllahir": stafTgllahir,
        "staf_alamat": stafAlamat,
        "staf_kelamin": stafKelamin,
        "staf_agama": stafAgama,
        "staf_telp": stafTelp,
        "staf_email": stafEmail,
        "staf_password": stafPassword,
        "staf_updatepassword": stafUpdatepassword,
        "staf_wa": stafWa,
        "staf_foto": stafFoto,
        "staf_status": stafStatus,
        "level_kode": levelKode,
        "level_nama": levelNama,
        "level_akses": levelAkses,
      };
}
