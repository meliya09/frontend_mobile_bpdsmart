class AppString {
  static final fetchApiData = "Fetch API Data";
  static final productList = "Product List";
}
