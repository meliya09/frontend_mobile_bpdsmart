import 'package:flutter/material.dart';

class AppColor {
  static final purpleColor = Colors.purple;
  static final grey = Colors.grey;
  static final grey200 = Colors.grey[200];
}
