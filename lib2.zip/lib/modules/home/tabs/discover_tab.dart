import 'package:bpdsmart_diy/routes/app_pages.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:get/get_navigation/src/snackbar/snackbar.dart';
import 'package:get/get_state_manager/src/simple/get_state.dart';

import '../../../services/internal_api/berita_terkini_services.dart';
import '../../internal/detail_product_internal/controllers/detail_product_internal_controller.dart';
import '../../internal/detail_product_internal/views/detail_product_internal_view.dart';
import '../../internal/detail_product_internal/bindings/detail_product_internal_binding.dart';
import '../../internal/detail_product_berita/controllers/detail_product_berita_controller.dart';
import '../../internal/detail_product_berita/views/detail_product_berita_view.dart';
import '../../internal/detail_product_berita/bindings/detail_product_berita_binding.dart';

import 'package:bpdsmart_diy/shared/constants/common.dart';
import 'package:flutter/material.dart';
import 'package:bpdsmart_diy/services/internal_api/berita_terkini_services.dart';
import 'package:bpdsmart_diy/services/internal_api/internal_services.dart';
import 'package:bpdsmart_diy/models/Internal/internal.dart';
import 'package:flutter_html/flutter_html.dart';

import 'package:http/http.dart';

class DiscoverTab extends GetView<DetailProductInternalController> {
  final data = Get.arguments;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
      child: Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(
              height: 25,
            ),
            Container(
              height: 45,
              decoration: BoxDecoration(
                color: Color.fromARGB(255, 185, 174, 174),
                borderRadius: BorderRadius.circular(
                  25.0,
                ),
              ),
              child: TabBar(
                isScrollable: true,
                controller: controller.tabController,
                // give the indicator a decoration (color and border radius)
                indicator: BoxDecoration(
                  borderRadius: BorderRadius.circular(
                    25.0,
                  ),
                  color: Colors.blue[900],
                ),
                labelColor: Colors.white,
                unselectedLabelColor: Colors.black,
                tabs: const [
                  Tab(
                    text: 'Judul Berita',
                    height: 100,
                  ),
                ],
              ),
            ),
            Expanded(
              child: TabBarView(
                controller: controller.tabController,
                children: [
                  SingleChildScrollView(
                    child: Column(
                      children: [
                        GetBuilder<DetailProductInternalController>(
                          init: DetailProductInternalController(),
                          builder: (_) {
                            // ignore: unnecessary_statements
                            Axis.vertical;
                            // ignore: always_specify_types
                            return FutureBuilder(
                              future: data == '93'
                                  ? BeritaTerkiniService().getInternals()
                                  : BeritaTerkiniService().getInternals(),
                              builder: (BuildContext context,
                                  AsyncSnapshot snapshot) {
                                if (snapshot.hasData) {
                                  return ListView.builder(
                                    shrinkWrap: true,
                                    itemCount: snapshot.data!.length,
                                    itemBuilder:
                                        (BuildContext context, int index) {
                                      return SingleChildScrollView(
                                          child: Card(
                                        clipBehavior: Clip.antiAlias,
                                        color:
                                            Color.fromARGB(255, 209, 201, 201),
                                        margin: const EdgeInsets.all(8),
                                        child: ListTile(
                                            leading: data == '93'
                                                ? const Icon(
                                                    FontAwesomeIcons.newspaper,
                                                    color: Colors.white)
                                                : const Icon(
                                                    FontAwesomeIcons.newspaper,
                                                    color: Colors.white),
                                            title: Text(
                                              snapshot.data![index].kontenJudul
                                                  .toString(),

                                              // style: heading1,
                                            ),
                                            trailing: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              // ignore: always_specify_types
                                              children: const [
                                                Icon(
                                                    FontAwesomeIcons.arrowRight,
                                                    color: Colors.white),
                                                Text(
                                                  'Lihat Detail',
                                                ),
                                              ],
                                            ),
                                            onTap: () {
                                              if (snapshot.data![index]
                                                          .kontenDeskripsi ==
                                                      null ||
                                                  snapshot.data![index]
                                                          .kontenDeskripsi ==
                                                      '' ||
                                                  snapshot.data![index]
                                                          .kontenDeskripsi ==
                                                      'null') {
                                                Get.snackbar(
                                                  'Perhatian',
                                                  'Belum ada konten',
                                                  snackPosition:
                                                      SnackPosition.TOP,
                                                  backgroundColor: Colors.red,
                                                  colorText: Colors.white,
                                                );
                                              } else {
                                                Get.toNamed(
                                                  Routes.DETAIL_PRODUCT_BERITA,
                                                  arguments:
                                                      snapshot.data![index],
                                                );
                                              }
                                            }),
                                      ));
                                    },
                                  );
                                } else {
                                  return const Center(
                                    child: CircularProgressIndicator(),
                                  );
                                }
                              },
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ));
  }
}
