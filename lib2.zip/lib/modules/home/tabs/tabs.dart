export 'discover_tab.dart';
export 'inbox_tab.dart';
export 'main_tab.dart';
export 'me_tab.dart';
export 'search_tab.dart';

enum MainTabs { home, discover, search, inbox, me }
