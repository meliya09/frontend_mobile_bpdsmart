import 'dart:math';
import 'package:bpdsmart_diy/models/InfoBerita/InfoBerita.dart';
import 'package:bpdsmart_diy/services/api.dart';
import 'package:bpdsmart_diy/models/response/users_response.dart';
import 'package:bpdsmart_diy/modules/home/home.dart';
import 'package:bpdsmart_diy/services/infoberita/infoberita_api.dart';
import 'package:bpdsmart_diy/shared/shared.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';

import '../../models/SearchMenu/search_model.dart';
import '../../services/popular_provider.dart';
import '../search_menu/networking/search_networking.dart';

class HomeController extends GetxController {
  final ApiRepository apiRepository;

  HomeController({required this.apiRepository});

  final RxBool isLoading = false.obs;
  Rx<MainTabs> currentTab = MainTabs.home.obs;
  Rxn<UsersResponse> users = Rxn<UsersResponse>();
  // ignore: always_specify_types
  Rxn user = Rxn<Datum>();

  RxList lstPopular = List<dynamic>.empty(growable: true).obs;
  RxBool isDataProcessing = false.obs;
  RxBool isDataError = false.obs;
  var data = Get.arguments;
  late MainTab mainTab;
  late DiscoverTab discoverTab;
  late SearchViews searchTab;
  late InboxTab inboxTab;
  late MeTab meTab;

  @override
  void onInit() async {
    super.onInit();

    mainTab = MainTab();
    // loadUsers();

    discoverTab = DiscoverTab();
    searchTab = SearchViews(
      category: '',
    );
    inboxTab = InboxTab();
    meTab = MeTab();
    fetchInfoBerita();
    getPopular();
  }

  //search
  var searchList = List<SearchMenu>.empty(growable: true).obs;
  List infoBeritaList = <InfoBerita>[].obs;

  void getSearch() async {
    final Search? search = await ApiService().getSearch(Get.arguments);

    try {
      if (search != null) {
        searchList.addAll(search.data);
      }
    } finally {
      isLoading(false);
    }
  }

  Future<void> fetchInfoBerita() async {
    isLoading.value = true;
    final Future<List<InfoBerita>> api = InfoBeritaService().getInfoBerita();
    final List<InfoBerita> result = await api;
    infoBeritaList = result;
    isLoading.value = false;
    update();
  }

  void getPopular() {
    try {
      isDataProcessing(true);
      PopularProvider().getPopular().then((List resp) {
        lstPopular.clear();
        isDataProcessing(false);
        lstPopular.addAll(resp);
        isDataError(false);
      }, onError: (err) {
        isDataProcessing(false);
        isDataError(true);
      });
    } catch (exception) {
      isDataProcessing(false);
      isDataError(true);
    }
  }

  void signout() {
    SharedPreferences prefs = Get.find<SharedPreferences>();
    prefs.clear();

    // Get.back();
    NavigatorHelper.popLastScreens(popCount: 2);
  }

  void _saveUserInfo(UsersResponse users) {
    Random random = new Random();
    int index = random.nextInt(users.data!.length);
    user.value = users.data![index];
    SharedPreferences prefs = Get.find<SharedPreferences>();
    prefs.setString(StorageConstants.userInfo, users.data![index].toRawJson());

    // var userInfo = prefs.getString(StorageConstants.userInfo);
    // var userInfoObj = Datum.fromRawJson(xx!);
    // print(userInfoObj);
  }

  void switchTab(index) {
    MainTabs tab = _getCurrentTab(index);
    currentTab.value = tab;
  }

  int getCurrentIndex(MainTabs tab) {
    switch (tab) {
      case MainTabs.home:
        return 0;
      case MainTabs.discover:
        return 1;
      case MainTabs.search:
        return 2;
      case MainTabs.inbox:
        return 3;
      case MainTabs.me:
        return 4;
      default:
        return 0;
    }
  }

  MainTabs _getCurrentTab(int index) {
    switch (index) {
      case 0:
        return MainTabs.home;
      case 1:
        return MainTabs.discover;
      case 2:
        return MainTabs.search;
      case 3:
        return MainTabs.inbox;
      case 4:
        return MainTabs.me;
      default:
        return MainTabs.home;
    }
  }

  @override
  void onReady() {
    super.onReady();
    getPopular();
  }

  @override
  void onClose() {
    super.onClose();
    getPopular();
  }
}
